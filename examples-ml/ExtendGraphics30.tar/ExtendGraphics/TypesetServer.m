



num = 1;

Loop[] :=
	Block[{ res, file, $TypesetLink, flag = True},
		$TypesetLink = LinkOpen[ LinkMode -> Listen] ;
		file = "/tmp/linkname" ;
		OpenWrite[ file] ;
		Write[file, First[ $TypesetLink]] ;
		Close[ file] ;
		Print[ "Link ", num," Opened"] ;
		num++ ;
		While[ flag,
			res = LinkRead[ $TypesetLink] ;
			If[ Head[ res] === linkGetTypesetPostScript,
					LinkWrite[ $TypesetLink, 
							Apply[ ConvertToPostScript, res]],
					flag = False]] ;
		num++;
		Loop[];
		]


Loop[]


