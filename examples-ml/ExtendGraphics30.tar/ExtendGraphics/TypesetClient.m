

file = "/tmp/linkname"
OpenRead[ file]
link = Read[ file]
Close[ file]
DeleteFile[ file]

$TypesetLink = LinkOpen[ link, LinkMode -> Connect]

If[ Head[ $TypesetLink] === LinkObject,

	Unprotect[ ConvertToPostScript];

	ConvertToPostScript[ e_] :=
		(LinkWrite[ $TypesetLink, linkGetTypesetPostScript[ e]];
	 	LinkRead[ $TypesetLink]);
	 
	TypesetSetDelayed[ lhs_, rhs_] :=
		(LinkWrite[ $TypesetLink, linkSetDelayed[ e, fmt]];
	 	LinkRead[ $TypesetLink]);

	CloseLink[ ] :=
		(LinkWrite[ $TypesetLink, foo[bar]]);
	]

(*

<<ExtendGraphics/TypesetClient.m

if problems then server is not started.

SetOptions[ Text, FormatType -> StandardForm]

Plot[ Sin[x^2], {x,0,2Pi},
                Epilog -> Text[ Sin[x^2], {3, .8}]]
        
TypesetSetDelayed[
        Typeset[ MyForm[x_], fmt_],
        FontBox[ Typeset[ x, fmt], FontSize -> 25]]
                
Plot[ Sin[x^2], {x,0,2Pi},
                Epilog -> Text[ MyForm[ Sin[x^2]], {3, .8}]]
        
This MyForm does'nt work.

*)





